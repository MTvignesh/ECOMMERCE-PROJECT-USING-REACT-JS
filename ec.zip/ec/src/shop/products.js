import p1 from './ph/gfd.jpeg'; 
import p2 from "./ph/ac.jpg";
import p3 from "./ph/vgv.png";
import p4 from "./ph/yv.jpg";
import p5 from "./ph/yyn.jpeg";
 
export const PRODUCTS=[
    {
        id:1,
        productName:"iphone",
        price :999.0,
        productImage:p1,

    },

    {
        id:2,
        productName:"redmi",
        price :559.0,
        productImage:p5,

    },
    {
        id:3,
        productName:"redm12",
        price :789.0,
        productImage:p5,

    },
    {
        id:4,
        productName:"moto",
        price :99.0,
        productImage:p3,

    },
    {
        id:5,
        productName:"samsung",
        price :989.0,
        productImage:p2,

    },
    {
        id:6,
        productName:"nano",
        price :999.0,
        productImage:p4,

    }
];
